import ImageCardList from './ImageCardList'
import './Miniheader.css'

export default function MiniHeader(){
    return (
        <div className="mini-header">
            
            <ImageCardList />
        </div>
    )
}